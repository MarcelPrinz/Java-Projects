package com.example.brutto_rechnungsbetrag;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    float nettoBetrag;
    float umsatzsteuerOutput = 19;
    float bruttoOutput;

    EditText nettobetragEingabe;
    EditText umsatzsteuer_19_ergebnis;
    EditText bruttobetrag_ergebnis;
    Button rechnen;

    View.OnClickListener listener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nettobetragEingabe = (EditText) findViewById(R.id.nettobetragEingabe);
        umsatzsteuer_19_ergebnis = (EditText) findViewById(R.id.umsatzsteuer_19_ergebnis);
        bruttobetrag_ergebnis = (EditText) findViewById(R.id.bruttobetrag_ergebnis);
        rechnen = (Button) findViewById(R.id.rechnen);
        listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Eingabe
                String nettobetragInput = nettobetragEingabe.getText().toString();
                nettoBetrag = Float.valueOf(nettobetragInput);
                    //String umsatzsteuerOutput = umsatzsteuer_19_ergebnis.getText()toString();
                    //umsatzsteuerOutput = Float.valueOf(umsatzsteuerOutput);
                    //String bruttobetragOutput = bruttobetrag_ergebnis.getText()toString();
                    //bruttoOutput = Float.valueOf(bruttobetragOutput);
                //Verarbeitung
                umsatzsteuerOutput = nettoBetrag / 100 * umsatzsteuerOutput;
                bruttoOutput = nettoBetrag + umsatzsteuerOutput;
                //Ausgabe
                umsatzsteuerOutput =((int) (umsatzsteuerOutput*100+0.5)) /100f;
                umsatzsteuer_19_ergebnis.setText(String.valueOf(umsatzsteuerOutput) + " €");
                bruttoOutput =((int) (bruttoOutput*100+0.5)) /100f;
                bruttobetrag_ergebnis.setText(String.valueOf(bruttoOutput) + " €");



            }
        };
        rechnen.setOnClickListener(listener);
    }
}